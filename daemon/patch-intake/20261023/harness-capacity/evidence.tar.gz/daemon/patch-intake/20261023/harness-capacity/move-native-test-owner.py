import pathlib,sys
pathlib.Path(sys.argv[1]).write_text('edit ae5359b1597f08583091267bea648a2f9e85f57b\npick 7989379490c15bafd1d7c8a5f7e5d52b5c89b708\n')
