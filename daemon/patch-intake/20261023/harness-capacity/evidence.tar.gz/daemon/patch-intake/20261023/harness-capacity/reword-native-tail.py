import pathlib,sys
p=pathlib.Path(sys.argv[1]);s=p.read_text();s=s.replace('fixup! rpc: isolate bounded commit owner without unrelated relay capability reversals','fixup! rpc: drain independent submissions through a bounded commit owner',1);p.write_text(s)
