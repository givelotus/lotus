// Copyright (c) 2026 The Lotus developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <config.h>
#include <consensus/amount.h>
#include <consensus/tx_check.h>
#include <core_io.h>
#include <kernel/disconnected_transactions.h>
#include <key_io.h>
#include <minerfund.h>
#include <node/snapshot.h>
#include <pow/pow.h>
#include <primitives/block.h>
#include <rpc/blockchain.h>
#include <rpc/server.h>
#include <script/standard.h>
#include <streams.h>
#include <test/util/setup_common.h>
#include <txmempool.h>
#include <univalue.h>
#include <util/strencodings.h>
#include <validation.h>

#include <boost/asio/co_spawn.hpp>
#include <boost/asio/detached.hpp>
#include <boost/asio/thread_pool.hpp>
#include <boost/test/unit_test.hpp>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <future>
#include <memory>
#include <thread>
#include <vector>

BOOST_FIXTURE_TEST_SUITE(rpc_snapshot_read_tests, TestChain100Setup)

BOOST_AUTO_TEST_CASE(snapshot_graph_ids_preserve_rpc_order_and_mining_dependencies) {
    // The graph is deliberately unchecked: this exercises snapshot graph
    // capture/selection, not script or consensus acceptance. A has two outputs
    // spent by join, so join must have only one dependency edge to A.
    CMutableTransaction parent_a;
    parent_a.vin.emplace_back(COutPoint(m_coinbase_txns[0]->GetId(), 0));
    parent_a.vout.emplace_back(100000 * SATOSHI, CScript() << OP_TRUE);
    parent_a.vout.emplace_back(100000 * SATOSHI, CScript() << OP_TRUE);
    auto pad = [](CMutableTransaction &tx) {
        while (::GetSerializeSize(tx) < MIN_TX_SIZE) {
            tx.vout[0].scriptPubKey << OP_NOP;
        }
    };
    pad(parent_a);
    CMutableTransaction parent_b = parent_a;
    parent_b.vin[0].prevout = COutPoint(m_coinbase_txns[1]->GetId(), 0);
    auto distinguish_order = [](const TxId &fixed, CMutableTransaction &other) {
        for (uint32_t nonce = 0; nonce < 256; ++nonce) {
            other.nLockTime = nonce;
            const auto id = other.GetId();
            if ((fixed < id) != (std::memcmp(fixed.begin(), id.begin(), 32) < 0)) {
                return true;
            }
        }
        return false;
    };
    BOOST_REQUIRE(distinguish_order(parent_a.GetId(), parent_b));
    const auto a = MakeTransactionRef(parent_a);
    const auto b = MakeTransactionRef(parent_b);
    CMutableTransaction join_tx;
    join_tx.vin.emplace_back(COutPoint(a->GetId(), 0));
    join_tx.vin.emplace_back(COutPoint(a->GetId(), 1));
    join_tx.vin.emplace_back(COutPoint(b->GetId(), 0));
    join_tx.vout.emplace_back(290000 * SATOSHI, CScript() << OP_TRUE);
    CMutableTransaction other_tx;
    other_tx.vin.emplace_back(COutPoint(b->GetId(), 1));
    other_tx.vout.emplace_back(98000 * SATOSHI, CScript() << OP_TRUE);
    pad(other_tx);
    BOOST_REQUIRE(distinguish_order(join_tx.GetId(), other_tx));
    const auto join = MakeTransactionRef(join_tx);
    const auto other = MakeTransactionRef(other_tx);
    auto &pool = *m_node.mempool;
    {
        LOCK2(cs_main, pool.cs);
        // Capture chain context before the unchecked additions. Their pending
        // overlay changes must remain deferred when the graph is published.
        node::PublishChainTipSnapshot(*m_node.chainman, &pool);
        CTxMemPool::ScopedSnapshotDefer defer(pool);
        pool.addUnchecked(TestMemPoolEntryHelper().Fee(Amount::zero()).FromTx(a));
        pool.addUnchecked(TestMemPoolEntryHelper().Fee(2000 * SATOSHI).FromTx(b));
        pool.addUnchecked(TestMemPoolEntryHelper().Fee(10000 * SATOSHI).FromTx(join));
        pool.addUnchecked(TestMemPoolEntryHelper().Fee(2000 * SATOSHI).FromTx(other));
    }
    const auto pinned = node::GetGlobalSnapshotPublisher().Load();
    BOOST_REQUIRE(pinned);
    const auto *join_entry = pinned->FindMempoolEntry(join->GetId());
    BOOST_REQUIRE(join_entry);
    BOOST_REQUIRE_EQUAL(join_entry->depends.size(), 2U);
    auto parents = std::vector<TxId>{a->GetId(), b->GetId()};
    std::sort(parents.begin(), parents.end());
    BOOST_CHECK(join_entry->depends == parents);

    auto rpc = [&](const std::string &method, UniValue params) {
        JSONRPCRequest request;
        request.context = &m_node;
        request.strMethod = method;
        request.params = std::move(params);
        return tableRPC.execute(GlobalConfig{}, request);
    };
    UniValue verbose_params(UniValue::VARR);
    verbose_params.push_back(true);
    const auto verbose = rpc("getrawmempool", std::move(verbose_params));
    auto check_edges = [&](const CTransactionRef &tx, const std::string &field,
                           std::vector<std::string> expected) {
        std::sort(expected.begin(), expected.end());
        UniValue params(UniValue::VARR);
        params.push_back(tx->GetId().ToString());
        const auto entry = rpc("getmempoolentry", std::move(params));
        const auto &edges = entry[field].get_array();
        const auto &verbose_edges = verbose[tx->GetId().ToString()][field].get_array();
        BOOST_REQUIRE_EQUAL(edges.size(), expected.size());
        BOOST_REQUIRE_EQUAL(verbose_edges.size(), expected.size());
        for (size_t i = 0; i < expected.size(); ++i) {
            BOOST_CHECK_EQUAL(edges[i].get_str(), expected[i]);
            BOOST_CHECK_EQUAL(verbose_edges[i].get_str(), expected[i]);
        }
    };
    check_edges(join, "depends", {a->GetId().ToString(), b->GetId().ToString()});
    check_edges(b, "spentby", {join->GetId().ToString(), other->GetId().ToString()});
    check_edges(a, "depends", {});
    check_edges(other, "spentby", {});

    // A cannot be mined at the minimum fee; join must remain blocked despite
    // its higher fee. The independent B -> other edge must unblock normally.
    BOOST_CHECK(!pinned->overlay_all_fit_candidate);
    const auto &tmpl = pinned->GetMiningTemplate();
    auto expected = std::vector<TxId>{b->GetId(), other->GetId()};
    if (pinned->ctor_active) std::sort(expected.begin(), expected.end());
    std::vector<TxId> selected;
    for (const auto &tx : tmpl.non_coinbase_txs) selected.push_back(tx->GetId());
    BOOST_CHECK(selected == expected);
    BOOST_CHECK(tmpl.total_fees == 4000 * SATOSHI);
    BOOST_CHECK(tmpl.tx_fees == std::vector<Amount>({2000 * SATOSHI, 2000 * SATOSHI}));
    BOOST_CHECK(tmpl.tx_sigchecks == std::vector<int64_t>({1, 1}));
}

BOOST_AUTO_TEST_CASE(header_only_snapshot_rechecks_new_block_metadata) {
    auto &manager = *m_node.chainman;
    BlockHash hash;
    unsigned int expected;
    {
        LOCK(::cs_main);
        auto *index = manager.ActiveChain()[50];
        hash = index->GetBlockHash();
        expected = index->nTx;
        // Capture the headers-only state before background download fills the
        // mutable block index, without changing the active chain's tip.
        index->nTx = 0;
        node::PublishChainTipSnapshot(manager, m_node.mempool.get());
        index->nTx = expected;
    }
    JSONRPCRequest request;
    request.context = &m_node;
    request.strMethod = "getblockheader";
    request.params = UniValue(UniValue::VARR);
    request.params.push_back(hash.GetHex());
    const auto result = tableRPC.execute(GlobalConfig{}, request);
    BOOST_CHECK_EQUAL(result["nTx"].getInt<int>(), expected);
}

BOOST_AUTO_TEST_CASE(lockfree_rpc_reads_while_cs_main_and_mempool_locked) {
    GlobalConfig config;
    auto call_rpc_params = [&](const std::string &method,
                               UniValue params) -> UniValue {
        JSONRPCRequest req;
        req.context = &m_node;
        req.strMethod = method;
        req.params = std::move(params);
        return tableRPC.execute(config, req);
    };
    auto call_rpc = [&](const std::string &method) -> UniValue {
        return call_rpc_params(method, UniValue(UniValue::VARR));
    };

    CScript pubKeyScript = GetScriptForRawPubKey(coinbaseKey.GetPubKey());
    CMutableTransaction mempool_mtx = CreateValidMempoolTransaction(
        m_coinbase_txns[0], 0, 1, coinbaseKey, pubKeyScript,
        50 * COIN - 1000 * SATOSHI, /*submit=*/true);
    const std::string mempool_txid = mempool_mtx.GetId().GetHex();
    const std::string confirmed_txid = m_coinbase_txns[1]->GetId().GetHex();
    const std::string spent_cb_txid = m_coinbase_txns[0]->GetId().GetHex();

    {
        LOCK(::cs_main);
        node::PublishChainTipSnapshot(*m_node.chainman, m_node.mempool.get());
    }

    // Ensure initial snapshot is published and matches active state.
    BOOST_CHECK_EQUAL(call_rpc("getblockcount").getInt<int>(), 100);
    const std::string block1_hash = [&]() {
        UniValue p(UniValue::VARR);
        p.push_back(1);
        return call_rpc_params("getblockhash", std::move(p)).get_str();
    }();
    const std::string block2_hash = [&]() {
        UniValue p(UniValue::VARR);
        p.push_back(2);
        return call_rpc_params("getblockhash", std::move(p)).get_str();
    }();

    std::promise<void> locks_acquired;
    std::promise<void> release_locks;
    auto release_future = release_locks.get_future();

    std::thread locker([&]() {
        LOCK2(::cs_main, m_node.mempool->cs);
        locks_acquired.set_value();
        release_future.wait();
    });

    locks_acquired.get_future().wait();

    // All migrated read-only RPCs must complete without blocking on cs_main
    // or mempool.cs while both locks are held exclusively by `locker`.
    const auto start = std::chrono::steady_clock::now();
    const UniValue count_res = call_rpc("getblockcount");
    const UniValue hash_res = call_rpc("getbestblockhash");
    const UniValue diff_res = call_rpc("getdifficulty");
    const UniValue info_res = call_rpc("getblockchaininfo");
    const UniValue mp_info_res = call_rpc("getmempoolinfo");
    const UniValue raw_mp_res = call_rpc("getrawmempool");

    UniValue verbose_mp_params(UniValue::VARR);
    verbose_mp_params.push_back(true);
    const UniValue raw_mp_verbose_res =
        call_rpc_params("getrawmempool", std::move(verbose_mp_params));

    UniValue mp_entry_params(UniValue::VARR);
    mp_entry_params.push_back(mempool_txid);
    const UniValue mp_entry_res =
        call_rpc_params("getmempoolentry", std::move(mp_entry_params));

    UniValue blockhash_params(UniValue::VARR);
    blockhash_params.push_back(2);
    const UniValue blockhash_res =
        call_rpc_params("getblockhash", std::move(blockhash_params));

    UniValue hdr_verbose_params(UniValue::VARR);
    hdr_verbose_params.push_back(block2_hash);
    hdr_verbose_params.push_back(true);
    const UniValue hdr_verbose_res =
        call_rpc_params("getblockheader", std::move(hdr_verbose_params));

    UniValue hdr_hex_params(UniValue::VARR);
    hdr_hex_params.push_back(block2_hash);
    hdr_hex_params.push_back(false);
    const UniValue hdr_hex_res =
        call_rpc_params("getblockheader", std::move(hdr_hex_params));

    UniValue txout_mempool_params(UniValue::VARR);
    txout_mempool_params.push_back(mempool_txid);
    txout_mempool_params.push_back(0);
    txout_mempool_params.push_back(true);
    const UniValue txout_mempool_res =
        call_rpc_params("gettxout", std::move(txout_mempool_params));

    UniValue txout_spent_params(UniValue::VARR);
    txout_spent_params.push_back(spent_cb_txid);
    txout_spent_params.push_back(0);
    txout_spent_params.push_back(true);
    const UniValue txout_spent_res =
        call_rpc_params("gettxout", std::move(txout_spent_params));

    UniValue rawtx_mp_params(UniValue::VARR);
    rawtx_mp_params.push_back(mempool_txid);
    rawtx_mp_params.push_back(true);
    const UniValue rawtx_mp_res =
        call_rpc_params("getrawtransaction", std::move(rawtx_mp_params));

    UniValue rawtx_blk_params(UniValue::VARR);
    rawtx_blk_params.push_back(confirmed_txid);
    rawtx_blk_params.push_back(true);
    rawtx_blk_params.push_back(block2_hash);
    const UniValue rawtx_blk_res =
        call_rpc_params("getrawtransaction", std::move(rawtx_blk_params));

    const auto elapsed_ms =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start)
            .count();

    release_locks.set_value();
    locker.join();

    BOOST_CHECK_LT(elapsed_ms, 500);
    BOOST_CHECK_EQUAL(count_res.getInt<int>(), 100);
    BOOST_CHECK_EQUAL(hash_res.get_str(),
                      info_res.find_value("bestblockhash").get_str());
    BOOST_CHECK_GT(diff_res.get_real(), 0.0);
    BOOST_CHECK_EQUAL(info_res.find_value("blocks").getInt<int>(), 100);
    BOOST_CHECK_EQUAL(mp_info_res.find_value("size").getInt<int>(), 1);
    BOOST_CHECK(raw_mp_res.isArray());
    BOOST_CHECK_EQUAL(raw_mp_res.size(), 1U);
    BOOST_CHECK(raw_mp_verbose_res.isObject());
    BOOST_CHECK(raw_mp_verbose_res.exists(mempool_txid));
    BOOST_CHECK_EQUAL(mp_entry_res.find_value("height").getInt<int>(), 100);
    BOOST_CHECK_EQUAL(blockhash_res.get_str(), block2_hash);
    BOOST_CHECK_EQUAL(hdr_verbose_res.find_value("hash").get_str(),
                      block2_hash);
    BOOST_CHECK_EQUAL(hdr_verbose_res.find_value("height").getInt<int>(), 2);
    BOOST_CHECK_EQUAL(hdr_verbose_res.find_value("previousblockhash").get_str(),
                      block1_hash);
    BOOST_CHECK(!hdr_hex_res.get_str().empty());
    BOOST_CHECK(txout_mempool_res.isObject());
    BOOST_CHECK_EQUAL(
        txout_mempool_res.find_value("confirmations").getInt<int>(), 0);
    BOOST_CHECK(!txout_mempool_res.find_value("coinbase").get_bool());
    BOOST_CHECK(txout_spent_res.isNull());
    BOOST_CHECK_EQUAL(rawtx_mp_res.find_value("txid").get_str(), mempool_txid);
    BOOST_CHECK_EQUAL(rawtx_blk_res.find_value("txid").get_str(),
                      confirmed_txid);
    BOOST_CHECK_EQUAL(rawtx_blk_res.find_value("blockhash").get_str(),
                      block2_hash);
    BOOST_CHECK(rawtx_blk_res.find_value("in_active_chain").get_bool());
    BOOST_CHECK_EQUAL(rawtx_blk_res.find_value("confirmations").getInt<int>(),
                      99);
}

BOOST_AUTO_TEST_SUITE_END()
